from email.policy import default
from xml.etree.ElementInclude import include
from django.contrib import admin
from django.urls import path ,include
from . import views
from Mpesa.views import TestView
from Mpesa.views import MakePayment





urlpatterns = [    
    path('Mpesa', TestView.as_view() , name='Mpesa'),
    path('MakePayment', MakePayment.as_view() , name='MakePayment')
]

