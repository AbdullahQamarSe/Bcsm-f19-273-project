from .access_token import generate_access_token
from rest_framework.views import APIView
from rest_framework.response import Response
from django.shortcuts import render
from.utils import timestamp_conversion
from .encode_base64 import generate_password
from django.conf import settings
import requests
import json

class TestView(APIView):
    def get(self,request,format=None):
        access_token = generate_access_token()
        formated_time = timestamp_conversion()
        decode_password = generate_password(formated_time)
        return Response({"access_token": access_token, "password":decode_password})

class MakePayment(APIView):
    def post(self,requests, *args, **kwargs):
        requestData = requests.data
        
        amount = requestData["amount"]
        phone  = requestData["phone_number"]
        
        paymentResponseData = self.make_mpesa_payment_request(amount=amount,phone=phone)
        return Response(paymentResponseData)
        
    def make_mpesa_payment_request(self,amount:str,phone:str) -> dict:
        access_token = generate_access_token()
        formated_time = timestamp_conversion()
        decode_password = generate_password(formated_time)
        
        headers = {"Authorization" : "Bearer %s" % access_token}
        
        request = {
            
        "ShortCode": settings.BUSINESS_SHORT_CODE,
        "CommandID":  settings.COMMAND_ID,
        "Amount": amount,
        "Msisdn": phone,
        "BillRefNumber": "null",
        }
        response = requests.post(settings.API_RESOURCE_URL, json=request ,headers=headers)
        print(request)
        return response